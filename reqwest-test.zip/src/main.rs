use std::sync::Arc;
use tokio::sync::Mutex;
use std::thread;

mod factory;
mod client;

#[tokio::main]
async fn main() -> Result<(), std::io::Error> {
    // for i in 0..4 {
    //     println!("thread {} is start..", i);
    //     thread::spawn(move || async {
    //
    //     });
    // }
    let client = Arc::new(Mutex::new(client::MyClient::new()));
    let _ = factory::Doings::new(
        client.clone()
    ).init().await.run().await.unwrap();
    Ok(())
}
